The Cannabis White Papers
=========================

51 evidence-linked cannabis cultivation field guides as clean markdown.
Drag this folder into a Claude Project, a Custom GPT's knowledge, or NotebookLM.

- papers/<slug>.md  : one paper each, citations as [^id] footnotes
- manifest.json     : index of all papers
- glossary.json     : defined terms

Licensed CC BY-NC 4.0 (https://creativecommons.org/licenses/by-nc/4.0/). Attribution: The Cannabis White Papers.
