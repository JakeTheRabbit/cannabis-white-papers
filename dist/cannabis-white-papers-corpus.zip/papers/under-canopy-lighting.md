---
slug: "under-canopy-lighting"
title: "Under-canopy and inter-canopy lighting for indoor cannabis"
eyebrow: "Environment · Lighting"
summary: "Under-canopy (SCL) and inter-canopy (ICL) lighting deliver photons to the lower canopy where overhead fixtures cannot reach. Controlled trials show that at equal total light output, depth-placed light upgrades bud grade and uniformity more reliably than it raises total yield. This paper covers light dose, spectrum, placement, plant training, and the thermal and airflow costs most guides omit. After reading it you can design an SCL or ICL retrofit and size its climate consequences."
track: "Environment & climate"
read_time: "~16 min read"
diagrams: "2 diagrams"
related: ["lighting-fundamentals", "airflow-design", "grow-room-systems", "defoliation-training", "mould-risk"]
url: "https://jaketherabbit.github.io/cannabis-white-papers/under-canopy-lighting.html"
md_url: "https://jaketherabbit.github.io/cannabis-white-papers/papers/under-canopy-lighting.md"
version: "1.2"
updated: "2026-07-18"
license: "CC BY-NC 4.0"
license_url: "https://creativecommons.org/licenses/by-nc/4.0/"
attribution: "The Cannabis White Papers"
refs: [{"id": "hawley2018-scl", "n": 1, "cite": "Hawley D, Graham T, Stasiak M, Dixon M (2018). Improving cannabis bud quality and yield with subcanopy lighting. HortScience 53(11):1593-1599.", "url": "https://doi.org/10.21273/HORTSCI13173-18", "peer": true}, {"id": "icl2025-plants", "n": 2, "cite": "(2025). Subcanopy and inter-canopy supplemental light enhances and standardizes yields in medicinal cannabis (Cannabis sativa L.). Plants 14(10):1469.", "url": "https://doi.org/10.3390/plants14101469", "peer": true}, {"id": "fluence-icl-2024", "n": 3, "cite": "Cannabis Business Times / Fluence (2024). Intercanopy lighting trials show compelling increases in cannabis quality and consistency (Texas Original; Poel, Hawley) — grade uplift at equal flux, photobleaching at 80-100% red.", "url": "https://www.cannabisbusinesstimes.com/", "peer": false}, {"id": "fluence-broad-2026", "n": 4, "cite": "Fluence (2026). Maximizing cannabis yields with intercanopy and subcanopy lighting — broad-spectrum recommendation, bleaching risk, ROI via uniformity.", "url": "https://fluence.science/", "peer": false}, {"id": "farred2025-scirep", "n": 5, "cite": "(2025). The effects of far-red light on medicinal cannabis. Scientific Reports 15.", "url": "https://doi.org/10.1038/s41598-025-99771-6", "peer": true}, {"id": "rm2021-light", "n": 6, "cite": "Rodriguez-Morrison V, Llewellyn D, Zheng Y (2021). Cannabis yield, potency, and leaf photosynthesis respond differently to increasing light levels in an indoor environment. Front. Plant Sci. 12:646020.", "url": "https://pmc.ncbi.nlm.nih.gov/articles/PMC8144505/", "peer": true}, {"id": "aroya-undercanopy", "n": 7, "cite": "AROYA. Understanding under-canopy lighting — realistic 25-35% averages, conditional on cultivar and plant-count accommodations.", "url": "https://aroya.io/", "peer": false}]
---

# Under-canopy and inter-canopy lighting for indoor cannabis

_Environment · Lighting · ~16 min read_

> Under-canopy (SCL) and inter-canopy (ICL) lighting deliver photons to the lower canopy where overhead fixtures cannot reach. Controlled trials show that at equal total light output, depth-placed light upgrades bud grade and uniformity more reliably than it raises total yield. This paper covers light dose, spectrum, placement, plant training, and the thermal and airflow costs most guides omit. After reading it you can design an SCL or ICL retrofit and size its climate consequences.

## Purpose and scope

A top fixture lights a roof, not a plant. Leaves absorb the wavelengths that drive photosynthesis—mainly red and blue—so each leaf layer strips those colours from the beam before it reaches the next. By the time light fights through three or four leaf layers, the lower third of the canopy receives a fraction of what its buds need to fill out, so it doesn’t. Under-canopy lighting (SCL) and inter-canopy lighting (ICL) put photons where the overhead array can’t, and the published work is now consistent: you don’t necessarily gain gross weight at equal total flux, but you upgrade grade, tighten uniformity, and lift the bottom of the plant from sparse, underweight bud to saleable flower.

None of that is free. Every watt you push below the canopy is a watt of heat in the worst-ventilated zone in the room, and you’re now growing dense bud in air that used to be dead space. This paper covers the light, the spectrum, the placement, the training, and—the part most guides skip—the thermal and airflow cost that comes due.

## Lower-canopy light deficit

Leaves are extremely efficient at absorbing the colours of light that drive photosynthesis—the process by which a leaf converts light energy into the sugars that feed plant growth. Think of it like a coloured filter: the upper leaves pull out the red and blue before the beam reaches the next layer. Each subsequent layer does the same. A top canopy running a healthy 800–1 200 µmol·m⁻²·s⁻¹ commonly drops to 100–200 µmol at the lower bud sites, well under the roughly 400–500 µmol level at which cannabis sets and fills competitive flower.

The result is what growers call larf: airy, underweight bud on the bottom third that grades B or C, drags your average down, and costs the same in labour to trim as your A-grade tops. The lower canopy isn’t underperforming because the genetics are weak there. It’s underperforming because it’s in the dark.

> **Diagram.** A top fixture lights a roof. PPFD falls from ~900 µmol at the apex to ~120 at the basal bud sites; under-canopy bars add the photons the top fixture can’t reach.

| Zone | PPFD | Meaning |
| --- | --- | --- |
| Top canopy | 800–1 200 µmol | Typical under a modern LED array |
| Basal bud sites | 100–200 µmol | What’s left after canopy attenuation |
| Common commercial band | 300–600 µmol | Typical target to fill lower flower (not a hard biological floor) |

*The geometry is the problem, and geometry needs a geometric fix: light delivered at depth, not just from above.*

> **NOTE — SCL vs ICL, not interchangeable**
>
> - **SCL (subcanopy / under-canopy):** bars on the bench, pot rims or floor, shining _up_ into the lower plant.
> - **ICL (inter-canopy / intracanopy):** bars hung _within_ the canopy, among the branches, at the basal and middle tiers.
> - Same goal, different mounting, different airflow consequences.

## Evidence on yield, quality and uniformity

The marketing decks all cite ‘20–60% yield gains’ without naming a source. The honest picture from peer-reviewed and controlled commercial work is more specific, and more useful, because it tells you _where_ the gain comes from.

**Hawley et al., 2018**, the Guelph group ran the first controlled cannabis subcanopy trial in _HortScience_[^hawley2018-scl]. Both red-blue and RGB SCL significantly increased yield _and_ THC in the lower-canopy bud. The mechanism: improved light distribution into the lower canopy beats simply raising overhead PPFD, the whole thesis of the field. Detail worth noting: in cycle two they _left the bottom growth on_ (instead of removing it) and the yield response was stronger. Under SCL, your defoliation logic inverts (Section 7).

**2025, top-light vs SCL vs ICL head to head**, a study in _Plants_ compared traditional top light against SCL and ICL directly[^icl2025-plants]. ICL was the standout, and both methods improved energy-use efficiency. The gain per watt was real, not just gross output bought with more power.

| Metric (ICL vs top-light control) | Result |
| --- | --- |
| Dry inflorescence yield | +30% (29.95%) |
| THC accumulation | +24% (24.4%) |
| Total terpene concentration | +12% (12.5%) |

*The 2025 Plants trial: ICL led on yield, potency and terpenes, and improved energy-use efficiency.*

**Fluence / Texas Original**. The trial that keeps you honest[^fluence-icl-2024]. At **equal total light flux**, moving photons into the canopy via ICL did _not_ reliably raise _total_ yield versus top-light alone, but it increased lower-canopy bud size and **upgraded the grade** (B/C → B/A) with much less variability. In a price-pressured market, consistency and grade are the margin, not gross weight.

> **TIP — The honest framing**
>
> If a vendor promises ‘+40% yield’, ask at what total flux. Adding fixtures adds photons adds yield, trivially. The defensible claim is: **at the same total power, do you get better grade and uniformity?** The controlled answer is yes. Field data lands realistic averages around 25–35%[^aroya-undercanopy], conditional on cultivar, a willingness to _reduce plant count_ for the fixtures and airflow, and the accommodations this paper covers. Achievable, not automatic.

## Spectrum selection below the canopy

Here’s the most expensive mistake in the category. Most under-canopy products are **heavy red**, cheap, efficient per photon, and look ‘powerful’. Heavy red is also the wrong spectrum below the canopy, and the trials prove it.

> **WARN — Photobleaching risk**
>
> Photobleaching is what happens when a leaf receives more light energy than its pigment system can process—like a photograph left in the sun, the pigments break down and the tissue loses colour and function. In the Fluence ICL trials, red intercanopy treatments at **80% and 100% red caused photobleaching**[^fluence-icl-2024]: the lower bud bleaches, loses pigment and degrades. They dropped to 60% red. Pushing a high-red bar into a dense lower canopy at close range bleaches the exact flower you were trying to save.

Two things are happening. First, the mid and lower canopy is _already_ green and far-red enriched—the upper leaves absorbed the blue and red on the way down. Stacking more concentrated red onto that imbalance is the opposite of what the plant needs. Second, the two photosynthetic reaction centres (photosystems I and II) must be excited roughly equally for efficient operation; monochromatic red unbalances them.

**Use a balanced, broad spectrum below the canopy**, closer to what the plant evolved under than to a red space heater. Broad-spectrum minimises bleaching risk while still driving photosynthesis[^fluence-broad-2026]; Hawley’s red-blue gave consistency, RGB moved terpenes more. Broad-spectrum white with a measured red component is the safe, productive default.

**Far-red (700–750 nm) is a scalpel, not a default.** Upside: adding far-red to a red or white source drives photosynthesis more efficiently than either colour alone—the two photosystems need different wavelengths and far-red satisfies the one red light neglects. End-of-day far-red raised cannabinoid yield in some cultivars[^farred2025-scirep]. Downside: far-red is the primary signal a plant uses to detect shade from neighbouring plants. When a plant detects it, the plant stretches upward looking for open sky—exactly the loose, airy growth you do not want low in the canopy. Dose it deliberately; never ‘more is better’.

| Spectrum | Verdict | Why |
| --- | --- | --- |
| Heavy red (80–100%) | Avoid | Bleaches lower bud; doubles down on an already red-skewed sub-canopy |
| Broad / white + moderate red | Default | Lowest bleaching risk, balanced photosystem excitation, proven yield + grade gains |
| Red-blue | Good | Consistent cannabinoid / terpene profile (Hawley) |
| RGB | Situational | Stronger terpene shift; more profile variability |
| + Far-red (dosed) | Scalpel | Photosynthetic efficiency gain + cannabinoid upside, but drives stretch—control it |

*Spectrum decision below the canopy. The category default should be broad, not red.*

## PAR targets and supplemental light

The goal isn’t to match top-canopy intensity at the floor. It’s to lift the starved zone over the threshold where bud development becomes viable, without bleaching.

| Zone | Unlit PPFD | Target with SCL/ICL | Intent |
| --- | --- | --- | --- |
| Apical (tops) | 800–1 200 | unchanged | Driven by the overhead array; don’t chase it higher |
| Middle | 300–450 | 500–700 | ICL territory, biggest grade upside |
| Basal | 100–200 | 300–600 | Lift over the ~400 viability floor |

*PPFD targets by stratum (flower), in µmol·m⁻²·s⁻¹.*

Think in **added flux at depth**, not bar wattage. A modest contribution—on the order of 25–60 W·m⁻² of installed sub-canopy fixture depending on geometry—is usually enough to clear the threshold. Past the bleaching point you’re paying in heat and pigment loss for negative return.

> **TIP — Hold total flux honest**
>
> To test whether SCL ‘works’, run it at **constant total facility flux** first (pull a little off the top, add it at depth) and measure grade and uniformity. That isolates the geometric benefit from the trivial ‘more light = more yield’ effect. Then decide whether to add net flux.

## How leaves adjust to their light environment

A leaf is not a fixed solar panel. While it is expanding, it builds its photosynthetic hardware—the internal structures, enzymes, and photoprotective pigments—calibrated to whatever light level it experiences _during_ development. Think of it like training for altitude: a body that trained at sea level does not perform the same at elevation, even with identical genetics. A leaf that grew in low light builds thin, low-capacity, lightly-defended tissue—not broken, optimised for its conditions. Biologists call this photoacclimation. Rodriguez-Morrison, Llewellyn & Zheng (2021) measured this directly in cannabis[^rm2021-light]: leaves acclimated to ~91 vs ~1 238 µmol differed in photosynthetic output by about **50%** at high intensity. Same cultivar, different light history, different machine.

**First implication: don’t trust a single leaf to predict the canopy.** The same study found leaf-level photosynthesis saturates well below where _whole-plant_ yield keeps climbing: dry inflorescence yield rose **linearly to 1 800 µmol** (the highest tested) while a single leaf’s curve flattened far earlier. Don’t size under-canopy targets off leaf-saturation measurements.

**Second implication: the lower leaves you’re about to light grew up in shade.** Their installed capacity is shade-grade. Too much light too fast overwhelms the photoprotective machinery before it can be rebuilt—the leaf cannot dissipate the excess energy safely and tissue is damaged before production begins. This is called photoinhibition. Newly-developing leaves re-acclimate far better than mature shade leaves, the mechanistic case for _ramping_ intensity rather than switching it on at full power (Section 10).

> **NOTE — Solid science vs grower practice**
>
> **Solid science:** light history shapes a leaf’s photosynthetic capacity—demonstrated in cannabis. **Grower practice, thin literature:** that a specific intensity ramp schedule changes cannabis yield. No published trial has tested ramp trajectories against constant intensity. Ramp because the acclimation mechanism says it lowers photoinhibition risk on shade-developed tissue, not because anyone has proven a specific number.

## Fixture placement and mounting

**SCL, bench / floor mount.** Bars on pot rims or low rails, throwing light upward into the basal bud sites:

- **Aim up and in.** Simplest to install and clean; lowest disruption to your canopy.
- **Standoff distance.** Keep enough gap that you’re not scorching the nearest bud. Bleaching risk scales with proximity and red fraction. Broad-spectrum tolerates closer placement.
- **Coverage uniformity.** Daisy-chained thin bars with overlapping throw beat a few point sources. Map it (Section 10), don’t eyeball it.

**ICL, in-canopy mount.** Bars hung within the branches at basal and middle tiers:

- **More effective for tall, unpruned genotypes**—exactly the architecture that benefits most. This is where the strongest study numbers came from.
- **Plan plant count down.** Bars in the canopy need lanes—the ‘reduce plant count’ accommodation the field data assumes.
- **Waterproof, cleanable, daisy-chainable.** These live in the humid, sprayed, trimmed zone. IP-rated housings and DLC certification (rebate eligibility) are baseline.

> **Diagram.** SCL lights from the bench upward, easy to install and clean. ICL places bars among the branches at multiple depths, stronger response on tall, unpruned plants, but it costs you plant lanes and airflow clearance.

## Plant training for under-canopy lighting

This separates operators who get the 30% from operators who bleach their bottoms and rot their cores. Under-canopy lighting and your training regime are one system, not two.

**The lollipopping reversal.** Standard practice strips the bottom 20 cm (8 in) of the plant—removing lower bud sites and foliage, sometimes called lollipopping or gyping—because that growth is shaded, contributes nothing, and invites rot. **Once you light it, that logic flips.** Hawley’s second cycle left the lower growth on precisely because SCL made those previously-useless leaves and bud sites productive. If you light the bottom then strip it, you’ve paid for fixtures to illuminate bare stem.

> **WARN — The trade-off you’re now managing**
>
> Keeping lower growth for the light _directly conflicts_ with the airflow and rot-prevention reasons you stripped it. You’re choosing to grow dense bud in the lowest, most humid, worst-ventilated zone. That’s only safe if Sections 8 and 9 are handled. Lighting the bottom without fixing the air is how you turn sparse larf into botrytis.

- **Keep:** lower bud sites and the leaves directly feeding them, now lit and earning.
- **Remove:** large fan leaves that _shade_ newly-lit bud sites or _trap humidity_ against them. Selective, not scorched-earth.
- **Tuck before you cut** where you can—redirect shade without removing photosynthetic area.
- **Even canopy / SCROG:** a trellised, evenly-spread canopy lets ICL bars thread through and lets air move. Packed hedges trap air.

**Timing:** run structural defoliation around the usual windows (~day 21, a lighter pass ~day 42 if still dense), but re-target it. You’re opening airflow lanes and removing shade _onto lit bud sites_, not clearing dead zone. Go light late in flower; aggressive late defoliation swings transpiration unpredictably in a zone you’ve made humid on purpose.

## Thermal load from under-canopy lighting

Ignore the marketing about LEDs ‘running cool’. For HVAC sizing, that claim is false in the way that matters. In a sealed room, **essentially all the electrical power you feed a fixture ends up as heat your HVAC has to remove.** A 600 W LED and a 600 W HPS impose the same cooling load. The LED’s advantage is hitting your target PPFD at _fewer watts_. You install fewer watts, not cooler ones.

Plants move water from roots to leaves and release it as vapour—like sweating, this cools the leaf but loads invisible moisture into the room air. This continuous water release is called transpiration, and the energy it takes to evaporate that water stays in the air as a latent heat load that does not switch off when lights go out. More on why that matters below.

> **NOTE — The core calculation**
>
> - Sensible heat added equals fixture wattage: **heat (W) = fixture watts** — in a sealed room, all electrical input becomes heat
> - To convert for imperial HVAC spec sheets: **BTU/hr = fixture watts × 3.412**
> - Worked example—20 m² (215 ft²) room: 25 W/m² × 20 = 500 W installed sub-canopy
> - 500 W sensible heat = **1 706 BTU/hr** on an imperial HVAC spec sheet
> - Cooling capacity: total watts ÷ 1 000 = kW of cooling needed · add +20% headroom (+30% sealed CO&sub2;) · round up

That 500 W sits on top of your overhead array, dehumidifier (nearly 100% of its wattage becomes in-room heat), equipment and people (~117 W / ~400 BTU/hr each). Lighting is typically 70–85% of total room cooling load before SCL. A retrofit is a direct, calculable increase to your single largest load. Size it deliberately; don’t assume your AC has the margin.

**How to measure your actual load:** sum measured wattage from driver labels and a clamp meter (not marketing specs); add dehumidifier watts (~1:1 to heat), people and ventilation infiltration; then validate against reality—log the lights-on temperature rise rate; if the room heats faster than your watt-based estimate predicts, you’ve under-counted a load.

> **WARN — The lights-off trap**
>
> Sensible heat drops to **zero the instant lights cut**, but the plants keep transpiring—releasing moisture into the room air. If cooling is oversized and dehumidification isn’t decoupled, temperature craters, relative humidity spikes to the dew point, and you get condensation on leaves: ideal conditions for botrytis and powdery mildew. SCL makes it worse: you’ve added transpiring bud mass low in the canopy. Decouple dehumidification from cooling.

## The lower-canopy microclimate

You have deliberately created flower in the worst-ventilated zone in the room. The lower canopy is where air stalls, humidity pools, and botrytis germinates inside dense colas from the inside out. Before SCL that zone was sparse larf or bare stem. Now it’s dense, transpiring bud. The airflow problem isn’t a side note. It’s the direct consequence of doing this at all.

- **Stagnant dead spots.** Overhead circulation fans sweep the top; the basal zone sits in still air below the airstream.
- **Added moisture load, low down.** New bud mass transpires into the zone with the least air movement. Moisture has nowhere to go.
- **Cold floor, warm air.** Condensation forms near pots and the lowest leaves first—exactly where you’ve put your new flower.

> **NOTE — Sizing the air**
>
> - Whole-room exchange: target a full air exchange every **1–3 minutes**
> - Flow rate needed: room volume (m³) ÷ exchange interval (min). Example: 68 m³ (2 400 ft³) ÷ 2 = **34 m³/min (1 200 CFM)**
> - Carbon-filter penalty: a scrubber adds ~20–25% static pressure—size the fan +25%, or rate it at 62 Pa (0.25″ water column), not free-air

That covers _bulk_ exchange. It does not solve the sub-canopy microclimate, because room-average airflow says nothing about the dead zone at the bottom. You need dedicated low-level air movement:

- **Dedicated low fans** aimed _through_ the lower canopy—the single biggest move once you light the bottom.
- **Sweep, never blast.** Gentle turbulent movement that flexes leaves, not a jet at the buds. Direct blasting dries trichomes and causes wind burn.
- **~one oscillating fan per 4–6 plants** as a starting density, biased to the lower tier.
- **Open the structure** (Section 7) so air can thread through. Fans can’t fix a packed hedge.

Vapour pressure deficit (VPD) measures how much more water vapour the air can absorb before it is saturated—think of it as the air’s thirst for moisture. Dry, warm air has high VPD and pulls moisture from leaves strongly; cool, humid air has low VPD and pulls less. **Manage VPD where the bud is, not just at the room sensor.** Reasonable flower targets are ~0.8–1.2 kPa early in flower, rising to 1.2–1.6 kPa late. Keep leaf temperature ~6–8 °C (11–14 °F) above the dew point, especially at lights-off. Put a sensor _in the lower canopy_—the basal zone reads wetter than room average, and that delta is exactly the risk SCL introduces.

> **WARN — The compounding failure**
>
> SCL adds bud mass → in the most humid zone → with the worst airflow → transpiring into still air → at lights-off when relative humidity spikes. Each factor is survivable alone. Stacked, they’re a botrytis machine. The lighting upgrade is only as good as the air and dehumidification upgrade that goes with it. Budget for both, or don’t do it.

## Commissioning under-canopy lighting

Don’t install to a spec sheet and walk away. Install, measure, adjust, log. The whole value of SCL is in the lower-canopy numbers, so that’s where you measure.

1. **Baseline map** — Before fitting bars, take PPFD at apical, middle and basal strata across a grid—quantum sensor, three directions at each point. This is your ‘before’.
2. **Install for uniformity, not peak** — Overlapping daisy-chained bars beat hot-spotted point sources. Set standoff generous initially; you can always move closer.
3. **Re-map** — Confirm middle/basal land in the target bands (500–700 / 300–600 µmol). Hunt for hot spots near fixtures. Those are your bleaching risks.
4. **Ramp, don't slam** — Bring sub-canopy intensity up over several days to catch early bleaching and because shade-developed leaves must re-acclimate before they can use the light productively (Section 5).
5. **Re-map the air** — Drop a temperature/RH sensor into the basal zone, compare to room average, add low fans until the delta closes and you hold the VPD and dew-point buffer at depth.
6. **Re-check thermal** — Log lights-on temperature rise against your watt-based heat estimate. Confirm cooling and decoupled dehumidification hold through a full lights-off transition.
7. **Hold flux constant for the first run** — Evaluate grade and uniformity against your geometric change before deciding to add net flux.
8. **Log per cultivar** — Response is cultivar-dependent: bleaching threshold, stretch under far-red, grade uplift. Dense, tall, unpruned genotypes gain most; some tight cultivars gain little and rot easily.

> **TIP — What to watch, in order of how fast it bites**
>
> **Bleaching** (days, near fixtures) → **basal RH / dew point** (every lights-off) → **stretch** (if running far-red) → **grade uniformity** (at harvest) → **energy-use efficiency** (per cycle, the number that justifies the capex).

## Expected results and limitations

The return on under-canopy lighting is mostly a **grade story**, not a gross-weight story. The clearest financial mechanism in the research is converting B/C-grade lower bud into A/B-grade saleable flower, plus reduced variability—worth more in a price-pressured, quality-led market than raw biomass.

| Line | Direction | Notes |
| --- | --- | --- |
| Bud grade uplift (B/C → A/B) | + revenue | The primary, best-evidenced return |
| Uniformity / reduced variability | + revenue | Predictable product, fewer culls |
| Yield at equal flux | ~ flat | Grade up, gross weight not guaranteed |
| Fixture capex + install | − capital | IP-rated, DLC for rebate eligibility |
| Added cooling + dehumidification | − capex/opex | Sections 8 + 9 — the hidden line |
| Reduced plant count (for ICL lanes) | − density | Fewer plants, better plants |
| Added power draw | − opex | Offset partly by energy-use-efficiency gains |

*Cost / benefit ledger. The return is grade and uniformity, with a real climate-accommodation cost.*

The realistic 25–35% average improvement is achievable[^aroya-undercanopy] — conditional on cultivar fit, plant-count discipline and the climate accommodations. Model it on _your_ grade spread and _your_ power and HVAC costs, not a vendor’s headline. If most of your lower canopy is already saleable, the upside is smaller. If you’re discarding larf every harvest, that larf is the prize.

## References

[^hawley2018-scl]: Hawley D, Graham T, Stasiak M, Dixon M (2018). Improving cannabis bud quality and yield with subcanopy lighting. HortScience 53(11):1593-1599. https://doi.org/10.21273/HORTSCI13173-18 (peer-reviewed)
[^icl2025-plants]: (2025). Subcanopy and inter-canopy supplemental light enhances and standardizes yields in medicinal cannabis (Cannabis sativa L.). Plants 14(10):1469. https://doi.org/10.3390/plants14101469 (peer-reviewed)
[^fluence-icl-2024]: Cannabis Business Times / Fluence (2024). Intercanopy lighting trials show compelling increases in cannabis quality and consistency (Texas Original; Poel, Hawley) — grade uplift at equal flux, photobleaching at 80-100% red. https://www.cannabisbusinesstimes.com/ (industry/manufacturer source)
[^fluence-broad-2026]: Fluence (2026). Maximizing cannabis yields with intercanopy and subcanopy lighting — broad-spectrum recommendation, bleaching risk, ROI via uniformity. https://fluence.science/ (industry/manufacturer source)
[^farred2025-scirep]: (2025). The effects of far-red light on medicinal cannabis. Scientific Reports 15. https://doi.org/10.1038/s41598-025-99771-6 (peer-reviewed)
[^rm2021-light]: Rodriguez-Morrison V, Llewellyn D, Zheng Y (2021). Cannabis yield, potency, and leaf photosynthesis respond differently to increasing light levels in an indoor environment. Front. Plant Sci. 12:646020. https://pmc.ncbi.nlm.nih.gov/articles/PMC8144505/ (peer-reviewed)
[^aroya-undercanopy]: AROYA. Understanding under-canopy lighting — realistic 25-35% averages, conditional on cultivar and plant-count accommodations. https://aroya.io/ (industry/manufacturer source)
